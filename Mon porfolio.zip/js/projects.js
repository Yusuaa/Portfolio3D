// Dans projects.js
const projects = [
  {
    title: "Portfolio Dynamique",
    language: "javascript",
    description: "Portfolio interactif avec Three.js",
    tools: ["Three.js", "JavaScript", "HTML5", "CSS3"],
    detailedDescription: `
        But : Créer un portfolio interactif et moderne
        Règles : Interface intuitive et responsive
        Objectifs : 
        - Présenter mes projets de manière interactive
        - Démontrer mes compétences en développement 3D
        - Créer une expérience utilisateur unique
    `,
    skills: [
        "Développement 3D avec Three.js",
        "Animation et transitions complexes",
        "Optimisation des performances",
        "Design responsive"
    ],
    images: [
        "/images/portfolio1.jpg",
        "/images/portfolio2.jpg",
        "/images/portfolio3.jpg"
    ]
    },
    { title: "E-commerce Platform", language: "react", description: "Plateforme de vente en ligne" },
    { title: "AI Task Manager", language: "python", description: "Gestionnaire de tâches avec IA" },
    { title: "CMS Personnalisé", language: "php", description: "Système de gestion de contenu" },
    { title: "Dashboard Analytics", language: "vue", description: "Tableau de bord en temps réel" },
    { title: "Chat Application", language: "javascript", description: "Application de messagerie" },
    { title: "Blog Platform", language: "react", description: "Plateforme de blog moderne" },
    { title: "Data Visualizer", language: "python", description: "Visualisation de données" },
    { title: "Social Network", language: "php", description: "Réseau social personnalisé" },
    { title: "Music Player", language: "javascript", description: "Lecteur de musique web" },
    { title: "Admin Dashboard", language: "vue", description: "Interface d'administration" },
    { title: "Weather App", language: "react", description: "Application météo" },
];

// S'assurer que la fonction est disponible globalement
window.initializeProjectsSection = function() {
  console.log('Initialisation des projets...');
  const projectsGrid = document.querySelector('.projects-grid');
  if (projectsGrid) {
      projectsGrid.innerHTML = generateProjectCards(1, 'all');
  }
  
  document.querySelectorAll('.filter-btn').forEach(btn => {
      btn.addEventListener('click', e => {
          const filter = e.target.dataset.language;
          document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
          e.target.classList.add('active');
          if (projectsGrid) {
              projectsGrid.innerHTML = generateProjectCards(1, filter);
          }
      });
  });
};

function generateProjectCards(page, filter = 'all') {
  const projectsPerPage = 6;
  const start = (page - 1) * projectsPerPage;
  const filteredProjects = filter === 'all' 
      ? projects 
      : projects.filter(p => p.language === filter);
  
  return filteredProjects
      .slice(start, start + projectsPerPage)
      .map(project => `
          <div class="project-card" onclick="showProjectDetails(${JSON.stringify(project).replace(/"/g, '&quot;')})">
              <h3 class="project-title">${project.title}</h3>
              <p>${project.description}</p>
              <span class="project-language">${project.language}</span>
          </div>
      `).join('');
}

function showProjectDetails(project) {
  // Masquer immédiatement tous les éléments, y compris le titre principal
  const menuElements = document.querySelectorAll('.projects-grid, .language-filter, .pagination, h2');
  menuElements.forEach(element => {
    element.style.visibility = 'hidden';
    element.style.opacity = '0';
  });

  const sceneElements = window.threeElements;
  
  if (!sceneElements || !sceneElements.scene) {
      console.error('Scene Three.js non disponible');
      return;
  }

  const camera = sceneElements.camera;
  const stars = sceneElements.stars;

  if (!camera || !stars) {
      console.error('Caméra ou étoiles non disponibles');
      return;
  }

  gsap.to(camera.position, {
      z: 15,
      duration: 2,
      ease: "power2.inOut"
  });
  
  gsap.to(stars.rotation, {
      x: stars.rotation.x + Math.PI * 2,
      y: stars.rotation.y + Math.PI * 2,
      duration: 2,
      ease: "power2.inOut"
  });

  const detailsElement = document.createElement('div');
  detailsElement.className = 'project-details';
  
  const clickedCard = event.currentTarget;
  const rect = clickedCard.getBoundingClientRect();
  
  // Mise à jour du style pour correspondre aux cartes de projet
  detailsElement.style.cssText = `
      position: fixed;
      top: ${rect.top}px;
      left: ${rect.left}px;
      width: ${rect.width}px;
      height: ${rect.height}px;
      background: none;
      backdrop-filter: blur(5px);
      border: 1px solid rgba(255, 215, 0, 0.3);
      border-radius: 20px;
      transition: all 0.8s cubic-bezier(0.4, 0, 0.2, 1);
      z-index: 1000;
      overflow: hidden;
      box-shadow: 0 8px 32px rgba(255, 215, 0, 0.1);
  `;

  // Mise à jour du template avec les nouveaux styles
  detailsElement.innerHTML = `
      <div class="details-content" style="opacity: 0; transition: opacity 0.6s ease-in;">
          <button class="close-button" style="
              background: none;
              border: 1px solid rgba(255, 215, 0, 0.3);
              backdrop-filter: blur(5px);
          ">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                  <path d="M18 6L6 18M6 6l12 12" stroke-width="2" stroke-linecap="round"/>
              </svg>
          </button>
          
          <div class="project-header" style="background: none;">
              <h2>${project.title}</h2>
              <div class="project-badges">
                  ${project.tools ? project.tools.map(tool => `<span class="badge">${tool}</span>`).join('') : ''}
              </div>
          </div>

          <div class="project-grid">
              <div class="project-content">
                  <section class="description-section glass-panel" style="
                      background: none;
                      border: 1px solid rgba(255, 215, 0, 0.3);
                      backdrop-filter: blur(5px);
                  ">
                      <h3>Description du projet</h3>
                      <div class="description-content">
                          ${project.detailedDescription ? project.detailedDescription.split('\n').map(line => `<p>${line}</p>`).join('') : ''}
                      </div>
                  </section>

                  <section class="skills-section glass-panel" style="
                      background: none;
                      border: 1px solid rgba(255, 215, 0, 0.3);
                      backdrop-filter: blur(5px);
                  ">
                      <h3>Compétences développées</h3>
                      <ul class="skills-list">
                          ${project.skills ? project.skills.map(skill => `
                              <li class="skill-item" style="
                                  background: none;
                                  border: 1px solid rgba(255, 215, 0, 0.3);
                                  backdrop-filter: blur(5px);
                              ">
                                  <span class="skill-icon">⭐</span>
                                  <span class="skill-text">${skill}</span>
                              </li>
                          `).join('') : ''}
                      </ul>
                  </section>
              </div>

              <div class="project-gallery glass-panel" style="
                  background: none;
                  border: 1px solid rgba(255, 215, 0, 0.3);
                  backdrop-filter: blur(5px);
              ">
                  <h3>Aperçu du projet</h3>
                  <div class="image-grid">
                      ${project.images ? project.images.map(img => `
                          <div class="image-container" style="border: 1px solid rgba(255, 215, 0, 0.3);">
                              <img src="${img}" alt="Aperçu du projet">
                          </div>
                      `).join('') : ''}
                  </div>
              </div>
          </div>
      </div>
  `;

  document.body.appendChild(detailsElement);

  requestAnimationFrame(() => {
      detailsElement.style.top = '50%';
      detailsElement.style.left = '50%';
      detailsElement.style.transform = 'translate(-50%, -50%)';
      detailsElement.style.width = '90vw';
      detailsElement.style.height = '90vh';
      
      setTimeout(() => {
          detailsElement.querySelector('.details-content').style.opacity = '1';
      }, 500);
  });

  detailsElement.querySelector('.close-button').addEventListener('click', () => {
      closeProjectDetails(camera, stars);
      
      // Réafficher les éléments du menu
      menuElements.forEach(element => {
          element.style.visibility = 'visible';
          gsap.to(element, {
              opacity: 1,
              duration: 0.5,
              delay: 0.3
          });
      });
  });
}
function closeProjectDetails() {
  const detailsElement = document.querySelector('.project-details');
  if (!detailsElement) return;

  const sceneElements = window.threeElements;
  if (!sceneElements || !sceneElements.camera || !sceneElements.stars) {
      console.error('Éléments Three.js non disponibles');
      return;
  }

  const { camera, stars } = sceneElements;

  // Supprimer les anciens éléments de fond s'ils existent
  const oldBackgrounds = document.querySelectorAll('.transition-background');
  oldBackgrounds.forEach(bg => bg.remove());

  // Stopper toutes les animations en cours sur detailsElement
  gsap.killTweensOf(detailsElement);
  gsap.killTweensOf(detailsElement.querySelector('.details-content'));

  // Animation de la caméra
  gsap.to(camera.position, {
      z: 6,
      duration: 1,
      ease: "power2.inOut"
  });

  // Animation des étoiles
  gsap.to(stars.rotation, {
      x: stars.rotation.x - Math.PI,
      y: stars.rotation.y - Math.PI,
      duration: 1,
      ease: "power2.inOut"
  });

  // Animation simple de fermeture
  const timeline = gsap.timeline({
      onComplete: () => {
          detailsElement.remove();
          
          // Réafficher les éléments du menu
          const menuElements = document.querySelectorAll('.projects-grid, .language-filter, .pagination, h2');
          menuElements.forEach(element => {
              element.style.visibility = 'visible';
          });
          
          // Animation simple de réapparition
          gsap.fromTo(menuElements, 
              { opacity: 0 },
              { 
                  opacity: 1,
                  duration: 0.5,
                  ease: "power2.out",
                  clearProps: "all" // Nettoie les propriétés après l'animation
              }
          );
      }
  });

  // Séquence d'animation simplifiée
  timeline
      .to(detailsElement.querySelector('.details-content'), {
          opacity: 0,
          duration: 0.3,
          ease: "power2.in"
      })
      .to(detailsElement, {
          opacity: 0,
          scale: 0.95,
          duration: 0.3,
          ease: "power2.in"
      });
}
console.log('Projects.js chargé');
